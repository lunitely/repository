# [GAY 🏳️‍🌈](https://ms-jpq.github.io/gay)

Colour your text / terminal to be more gay.

Gayer version of [`lolcat`](https://github.com/busyloop/lolcat)

## [Get Gay](https://pypi.org/project/gay)

`pip3 install -U gay`

## Show me

### Text

```sh
echo 'message' | gay
```

![help.png](https://raw.githubusercontent.com/ms-jpq/gay/%3C3/preview/help.png)

```sh
-i 1d, --interpolation 1d
```

![1d.png](https://raw.githubusercontent.com/ms-jpq/gay/%3C3/preview/1d.png)

```sh
-i 2d, --interpolation 2d
```

![2d.png](https://raw.githubusercontent.com/ms-jpq/gay/%3C3/preview/2d.png)

### Flag

```sh
gay --flag
```

Unlike the demo, it shows 1 flag and 1 flag only.

![flags.gif](https://raw.githubusercontent.com/ms-jpq/gay/%3C3/preview/flags.gif)

## Thank yous

[nshepperd](https://github.com/nshepperd) for helping with 2D gradient

[wrennnnnn](https://github.com/wrennnnnn) for helping with windows
